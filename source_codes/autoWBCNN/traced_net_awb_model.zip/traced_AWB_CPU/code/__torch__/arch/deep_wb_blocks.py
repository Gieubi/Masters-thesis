class DoubleConvBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  double_conv : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.arch.deep_wb_blocks.DoubleConvBlock,
    x: Tensor) -> Tensor:
    double_conv = self.double_conv
    return (double_conv).forward(x, )
class DownBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  maxpool_conv : __torch__.torch.nn.modules.container.___torch_mangle_8.Sequential
  def forward(self: __torch__.arch.deep_wb_blocks.DownBlock,
    argument_1: Tensor) -> Tensor:
    maxpool_conv = self.maxpool_conv
    _0 = (maxpool_conv).forward(argument_1, )
    return _0
class BridgeDown(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  maxpool_conv : __torch__.torch.nn.modules.container.___torch_mangle_30.Sequential
  def forward(self: __torch__.arch.deep_wb_blocks.BridgeDown,
    argument_1: Tensor) -> Tensor:
    maxpool_conv = self.maxpool_conv
    _1 = (maxpool_conv).forward(argument_1, )
    return _1
class BridgeUP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv_up : __torch__.torch.nn.modules.container.___torch_mangle_33.Sequential
  def forward(self: __torch__.arch.deep_wb_blocks.BridgeUP,
    argument_1: Tensor) -> Tensor:
    conv_up = self.conv_up
    return (conv_up).forward(argument_1, )
class UpBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.arch.deep_wb_blocks.___torch_mangle_39.DoubleConvBlock
  up : __torch__.torch.nn.modules.conv.___torch_mangle_40.ConvTranspose2d
  def forward(self: __torch__.arch.deep_wb_blocks.UpBlock,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    up = self.up
    conv = self.conv
    input = torch.cat([argument_1, argument_2], 1)
    _2 = (up).forward((conv).forward(input, ), )
    return torch.relu(_2)
class OutputBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  out_conv : __torch__.torch.nn.modules.container.___torch_mangle_64.Sequential
  def forward(self: __torch__.arch.deep_wb_blocks.OutputBlock,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    out_conv = self.out_conv
    input = torch.cat([argument_1, argument_2], 1)
    return (out_conv).forward(input, )
