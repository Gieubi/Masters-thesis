class UpBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.arch.deep_wb_blocks.___torch_mangle_54.DoubleConvBlock
  up : __torch__.torch.nn.modules.conv.___torch_mangle_55.ConvTranspose2d
  def forward(self: __torch__.arch.deep_wb_blocks.___torch_mangle_56.UpBlock,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    up = self.up
    conv = self.conv
    input = torch.cat([argument_1, argument_2], 1)
    _0 = (up).forward((conv).forward(input, ), )
    return torch.relu(_0)
