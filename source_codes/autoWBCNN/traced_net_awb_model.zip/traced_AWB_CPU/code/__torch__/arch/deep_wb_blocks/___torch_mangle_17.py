class DownBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  maxpool_conv : __torch__.torch.nn.modules.container.___torch_mangle_16.Sequential
  def forward(self: __torch__.arch.deep_wb_blocks.___torch_mangle_17.DownBlock,
    argument_1: Tensor) -> Tensor:
    maxpool_conv = self.maxpool_conv
    _0 = (maxpool_conv).forward(argument_1, )
    return _0
