class DoubleConvBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  double_conv : __torch__.torch.nn.modules.container.___torch_mangle_53.Sequential
  def forward(self: __torch__.arch.deep_wb_blocks.___torch_mangle_54.DoubleConvBlock,
    input: Tensor) -> Tensor:
    double_conv = self.double_conv
    return (double_conv).forward(input, )
