class deepWBnet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoder_inc : __torch__.arch.deep_wb_blocks.DoubleConvBlock
  encoder_down1 : __torch__.arch.deep_wb_blocks.DownBlock
  encoder_down2 : __torch__.arch.deep_wb_blocks.___torch_mangle_17.DownBlock
  encoder_down3 : __torch__.arch.deep_wb_blocks.___torch_mangle_26.DownBlock
  encoder_bridge_down : __torch__.arch.deep_wb_blocks.BridgeDown
  decoder_bridge_up : __torch__.arch.deep_wb_blocks.BridgeUP
  decoder_up1 : __torch__.arch.deep_wb_blocks.UpBlock
  decoder_up2 : __torch__.arch.deep_wb_blocks.___torch_mangle_48.UpBlock
  decoder_up3 : __torch__.arch.deep_wb_blocks.___torch_mangle_56.UpBlock
  decoder_out : __torch__.arch.deep_wb_blocks.OutputBlock
  def forward(self: __torch__.arch.deep_wb_single_task.deepWBnet,
    x: Tensor) -> Tensor:
    decoder_out = self.decoder_out
    decoder_up3 = self.decoder_up3
    decoder_up2 = self.decoder_up2
    decoder_up1 = self.decoder_up1
    decoder_bridge_up = self.decoder_bridge_up
    encoder_bridge_down = self.encoder_bridge_down
    encoder_down3 = self.encoder_down3
    encoder_down2 = self.encoder_down2
    encoder_down1 = self.encoder_down1
    encoder_inc = self.encoder_inc
    _0 = (encoder_inc).forward(x, )
    _1 = (encoder_down1).forward(_0, )
    _2 = (encoder_down2).forward(_1, )
    _3 = (encoder_down3).forward(_2, )
    _4 = (decoder_bridge_up).forward((encoder_bridge_down).forward(_3, ), )
    _5 = (decoder_up2).forward(_2, (decoder_up1).forward(_3, _4, ), )
    _6 = (decoder_out).forward(_0, (decoder_up3).forward(_1, _5, ), )
    return _6
